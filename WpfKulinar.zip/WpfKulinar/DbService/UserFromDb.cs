﻿using System;
using System.Windows;
using Npgsql;
using NpgsqlTypes;
using WpfKulinar.Domain;
using WpfKulinar.Model;

namespace WpfKulinar.DbService
{
    internal class UserFromDb
    {
        public User GetUser(string login, string password)
        {
            User user = null;
            string query = "select user_id, first_name, last_name, patronymic, date_of_birthday, login, password, adress, role_id, phone " +
                           "from users where login = @login";

            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnect.ConnectionString))
                {
                    connection.Open();
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("login", login);
                        using (NpgsqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                if (Verification.VerifySHA512Hash(password, reader.GetString(6)))
                                {
                                    int userId = reader.GetInt32(0);
                                    string firstName = reader.GetString(1);
                                  string lastName = reader.GetString(2);
                                    string patronymic = reader.IsDBNull(3) ? "" : reader.GetString(3);
                                   DateTime dateOfBirthday = reader.IsDBNull(4) ? DateTime.MinValue : reader.GetDateTime(4);
                                    string userLogin = reader.GetString(5);
                                    string hash = reader.GetString(6);
                                    string adress = reader.IsDBNull(7) ? "" : reader.GetString(7);
                                    int roleId = reader.GetInt32(8);
                                    string phone = reader.IsDBNull(9) ? "" : reader.GetString(9);

                                    user = new User(userId, firstName, lastName, patronymic, dateOfBirthday,
                                                    userLogin, hash, adress, roleId, phone);
                                }
                                else
                                {
                                    MessageBox.Show("Неверный пароль");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Нет такого пользователя");
                            }
                        }
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return user;
        }

        public bool CheckPassword(string password, string passRepeat)
        {
            if (password.Length < 6)
            {
                MessageBox.Show("Длина пароля не может быть меньше 6 символов");
                return false;
            }

            bool hasDigit = false;
            bool hasUpper = false;
            bool hasSymbol = false;
            string symbols = "!@#$%^";

            foreach (char c in password)
            {
                if (char.IsDigit(c)) hasDigit = true;
                if (char.IsUpper(c)) hasUpper = true;
                if (symbols.Contains(c)) hasSymbol = true;
            }

            if (!hasDigit || !hasUpper)
            {
                MessageBox.Show("Пароль должен содержать хотя бы одну цифру и одну заглавную букву!");
                return false;
            }

            if (!hasSymbol)
            {
                MessageBox.Show("Пароль должен содержать один из символов !@#$%^");
                return false;
            }

            if (password != passRepeat)
            {
                MessageBox.Show("Неверно подтвержден пароль");
                return false;
            }
            return true;
        }

        public bool CheckUser(string login)
        {
            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnect.ConnectionString))
                {
                    connection.Open();
                    string query = "select login from users where login = @login";
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("login", login);
                        using (NpgsqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                MessageBox.Show("Такой логин уже есть");
                                return false;
                            }
                            return true;
                        }
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public void UserAdd(string login, string password, string firstName, string lastName)
        {
            string hash = Verification.GetSHA512Hash(password);
            string query = "insert into users (first_name, last_name, login, password) values (@firstName, @lastName, @login, @password)";

            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnect.ConnectionString))
                {
                    connection.Open();
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("firstName", firstName);
                      command.Parameters.AddWithValue("lastName", lastName);
                        command.Parameters.AddWithValue("login", login);
                        command.Parameters.AddWithValue("password", hash);
                        command.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Регистрация прошла успешно");
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void UserUpdateProfil(User user, bool isPasswordChanged)
        {
            string query = "update users set first_name = @firstName, last_name = @lastName, patronymic = @patronymic, " +
                           "date_of_birthday = @birthday, phone = @phone, adress = @adress";
            if (isPasswordChanged)
            {
                query += ", password = @password";
            }
            query += " where user_id = @userId";

            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnect.ConnectionString))
                {
                    connection.Open();
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("firstName", user.FirstName);
                        command.Parameters.AddWithValue("lastName", user.LastName);
                        command.Parameters.AddWithValue("patronymic", string.IsNullOrWhiteSpace(user.Patronymic) ? DBNull.Value : (object)user.Patronymic);
                        command.Parameters.AddWithValue("birthday", NpgsqlDbType.Date, user.DateOfBirthday == DateTime.MinValue ? DBNull.Value : (object)user.DateOfBirthday);
                        command.Parameters.AddWithValue("phone", string.IsNullOrWhiteSpace(user.Phone) ? DBNull.Value : (object)user.Phone);
                        command.Parameters.AddWithValue("adress", string.IsNullOrWhiteSpace(user.Adress) ? DBNull.Value : (object)user.Adress);
                        command.Parameters.AddWithValue("userId", user.UserId);
                        if (isPasswordChanged)
                        {
                            command.Parameters.AddWithValue("password", user.Password);
                        }
                        command.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Данные сохранены");
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
