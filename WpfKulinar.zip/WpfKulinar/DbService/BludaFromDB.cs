﻿using System.Collections.ObjectModel;
using Npgsql;
using WpfKulinar.Model;

namespace WpfKulinar.DbService
{
    internal class BludaFromDB
    {
        public ObservableCollection<Bludo> LoadBludos()
        {
         ObservableCollection<Bludo> bludos =  new ObservableCollection<Bludo>();

          string query = "select b.bludo_id, b.bludo_name, c.category_name, b.osnova, b.vihod, b.bludo_image " +
                           "from bluda b left join category_bluda c on b.id_categirya = c.category_id " +
                           "order by b.bludo_id";

            using (NpgsqlConnection connection = new NpgsqlConnection(DbConnect.ConnectionString))
            {
            connection.Open();
            using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
            using (NpgsqlDataReader reader  = command.ExecuteReader())
            {
             while (reader.Read())
                    {
                     int id = reader.GetInt32(0);
                     string name = reader.IsDBNull(1) ? "" : reader.GetString(1);
                      string categoriya = reader.IsDBNull(2) ? "" : reader.GetString(2);
                     string osnova = reader.IsDBNull(3) ? "" : reader.GetString(3);
                     int vyhod = reader.IsDBNull(4) ? 0 : reader.GetInt32(4);
                     string image = reader.IsDBNull(5) ? "" : reader.GetString(5);

                     bludos.Add(new Bludo(id, name, categoriya, osnova, vyhod, image));
                    }
                }
            }
                     return bludos;
        }
    }
}
