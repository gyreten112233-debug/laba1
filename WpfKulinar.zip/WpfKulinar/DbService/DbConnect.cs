﻿namespace WpfKulinar.DbService
{
    internal class DbConnect
    {
        public static string ConnectionString = "Host=172.20.105.123;Port=5432;Database=kulinary_yakushkin1;Username=9tm12-24-27;Password=Cstyler1337";
    }
}
