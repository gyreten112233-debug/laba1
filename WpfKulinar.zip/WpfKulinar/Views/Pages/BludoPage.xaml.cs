﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using WpfKulinar.DbService;
using WpfKulinar.Model;

namespace WpfKulinar.Views.Pages
{
    public partial class BludoPage : Page
    {
        BludaFromDB bludaFromDB = new BludaFromDB();
        ObservableCollection<Bludo> listBludos = new ObservableCollection<Bludo>();

        public BludoPage()
        {
            InitializeComponent();
        }

        private void AllBludos()
        {
            listBludos = bludaFromDB.LoadBludos();
            listViewBludas.ItemsSource = listBludos;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            AllBludos();

            if (AuthWindow.currentUser.RoleId == 2)
            {
                btnAdd.Visibility = Visibility.Collapsed;
            }
        }
          
        }
    }