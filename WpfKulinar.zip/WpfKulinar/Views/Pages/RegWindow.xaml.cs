﻿using System.Windows;
using WpfKulinar.DbService;

namespace WpfKulinar.Views
{
    public partial class RegWindow : Window
    {
        UserFromDb userFromDb = new UserFromDb();

        public RegWindow()
        {
            InitializeComponent();
        }

        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxName.Text) || string.IsNullOrWhiteSpace(textBoxFam.Text) ||
                string.IsNullOrWhiteSpace(textBoxLogin.Text) || passwordPwd.Password == "" || passwordPwdP.Password == "")
            {
                MessageBox.Show("Необходимо заполнить все поля!");
                return;
            }

            if (!userFromDb.CheckPassword(passwordPwd.Password, passwordPwdP.Password))
            {
                return;
            }

            if (!userFromDb.CheckUser(textBoxLogin.Text))
            {
                return;
            }

            userFromDb.UserAdd(textBoxLogin.Text, passwordPwd.Password, textBoxName.Text, textBoxFam.Text);

            AuthWindow authWindow = new AuthWindow();
            authWindow.Show();
            Close();
        }
    }
}  