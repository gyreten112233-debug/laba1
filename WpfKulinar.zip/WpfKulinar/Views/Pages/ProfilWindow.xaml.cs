﻿using System;
using System.Windows;
using System.Windows.Controls.Primitives;
using WpfKulinar.DbService;
using WpfKulinar.Domain;
using WpfKulinar.Model;

namespace WpfKulinar.Views
{
    public partial class ProfilWindow : Window
    {
        UserFromDb userFromDb = new UserFromDb();
        bool isPasswordChanged = false;

        public ProfilWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            User user = AuthWindow.currentUser;

            textBoxName.Text = user.FirstName;
            textBoxPatronymic.Text = user.Patronymic;
            textBoxLastName.Text = user.LastName;
            if (user.DateOfBirthday != DateTime.MinValue)
            {
                datePickerBirthday.SelectedDate = user.DateOfBirthday;
            }
            textBoxPhone.Text = user.Phone;
            textBoxAdress.Text = user.Adress;
        }

        private void btnChangePassword_Click(object sender, RoutedEventArgs e)
        {
            panelPassword.Visibility = Visibility.Visible;
            btnChangePassword.Visibility = Visibility.Collapsed;
            isPasswordChanged = true;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxName.Text) || string.IsNullOrWhiteSpace(textBoxLastName.Text))
            {
                MessageBox.Show("Имя и фамилия должны быть заполнены");
                return;
            }

            User user = AuthWindow.currentUser;

            if (isPasswordChanged)
            {
                if (passwordOld.Password == "" || passwordNew.Password == "" || passwordRepeat.Password == "")
                {
                    MessageBox.Show("Заполните все поля для смены пароля");
                    return;
                }

                if (!Verification.VerifySHA512Hash(passwordOld.Password, user.Password))
                {
                    MessageBox.Show("Неверный старый пароль");
                    return;
                }

                if (!userFromDb.CheckPassword(passwordNew.Password, passwordRepeat.Password))
                {
                    return;
                }
            }

            user.FirstName = textBoxName.Text;
            user.Patronymic = textBoxPatronymic.Text;
            user.LastName = textBoxLastName.Text;
            user.DateOfBirthday = datePickerBirthday.SelectedDate ?? DateTime.MinValue;
            user.Phone = textBoxPhone.Text;
            user.Adress = textBoxAdress.Text;

            if (isPasswordChanged)
            {
                user.Password = Verification.GetSHA512Hash(passwordNew.Password);
            }

            userFromDb.UserUpdateProfil(user, isPasswordChanged);
            Close();
        }
    }
}
