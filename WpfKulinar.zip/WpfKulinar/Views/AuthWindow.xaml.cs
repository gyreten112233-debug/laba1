﻿using System.Windows;
using WpfKulinar.DbService;
using WpfKulinar.Model;

namespace WpfKulinar.Views
{
    public partial class AuthWindow : Window
    {
        UserFromDb userFromDb = new UserFromDb();
        public static User currentUser = null;

        public AuthWindow()
        {
            InitializeComponent();
        }

        private void btnAuth_Click(object sender, RoutedEventArgs e)
        {
            if (login.Text == "" || password.Password == "")
            {
                MessageBox.Show("Введите данные");
                return;
            }

            currentUser = userFromDb.GetUser(login.Text, password.Password);
            if (currentUser != null)
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                Close();
            }
        }

        private void btnRegistration_Click(object sender, RoutedEventArgs e)
        {
            RegWindow regWindow = new RegWindow();
            regWindow.Show();
            Close();
        }
    }
}
