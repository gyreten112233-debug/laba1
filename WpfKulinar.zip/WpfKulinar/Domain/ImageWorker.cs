﻿using System;
using System.IO;

namespace WpfKulinar.Domain
{
    internal class ImageWorker
    {
        string folderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "..", "Images");

        public string ImagePath(string imageName)
        {
            string path = Path.GetFullPath(Path.Combine(folderPath, "picture.jpg"));

            if (!string.IsNullOrEmpty(imageName) && !string.IsNullOrWhiteSpace(imageName))
            {
                string fullPath = Path.GetFullPath(Path.Combine(folderPath, imageName));
                if (File.Exists(fullPath))
                {
                    path = fullPath;
                }
            }
            return path;
        }
    }
}
