﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace WpfKulinar.Domain
{
    internal class Verification
    {
        public static string GetSHA512Hash(string input)
        {
            byte[] data;
            using (SHA512 sha512 = SHA512.Create())
            {
                data = sha512.ComputeHash(Encoding.UTF8.GetBytes(input));
            }

            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < data.Length; i++)
            {
                builder.Append(data[i].ToString("x2"));
            }
            return builder.ToString();
        }

        public static bool VerifySHA512Hash(string input, string hash)
        {
            string hashOfInput = GetSHA512Hash(input);
            StringComparer comparer = StringComparer.OrdinalIgnoreCase;
            return comparer.Compare(hashOfInput, hash) == 0;
        }
    }
}
