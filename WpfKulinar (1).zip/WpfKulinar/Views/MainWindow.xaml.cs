﻿using System.Windows;
using System.Windows.Controls;
using WpfKulinar.Model;

namespace WpfKulinar.Views
{
    public partial class MainWindow : Window
    {
        public static Frame frameBludo = null;
        public static Frame frameProduct = null;
        public static Frame frameUsers = null;

        public MainWindow()
        {
            InitializeComponent();
            tabProfil.Visibility = Visibility.Collapsed;

            frameBludo = bludoFrame;
            frameProduct = productFrame;
            frameUsers = usersFrame;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            User user = AuthWindow.currentUser;
            userName.Text = user.LastName + " " + user.FirstName;

            frameBludo.Navigate(new Pages.BludoPage());
            frameProduct.Navigate(new Pages.ProductPage());

            if (user.RoleId == 1)
            {
                tabProfil.Visibility = Visibility.Visible;
                frameUsers.Navigate(new Pages.AdminPage());
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            AuthWindow.currentUser = null;
            AuthWindow authWindow = new AuthWindow();
            authWindow.Show();
            Close();
        }

        private void btnProfil_Click(object sender, RoutedEventArgs e)
        {
            ProfilWindow profilWindow = new ProfilWindow();
            profilWindow.ShowDialog();
            User user = AuthWindow.currentUser;
            userName.Text = user.LastName + " " + user.FirstName;
        }
    }
}
