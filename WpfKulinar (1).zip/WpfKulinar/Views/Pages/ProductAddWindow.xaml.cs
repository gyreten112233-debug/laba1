﻿using System.Windows;
using WpfKulinar.DbService;
using WpfKulinar.Model;

namespace WpfKulinar.Views
{
    public partial class ProductAddWindow : Window
    {
        ProductFromDb productFromDb = new ProductFromDb();

        public ProductAddWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            string name = textBoxName.Text.Trim();

            if (name == "" || textBoxBelki.Text.Trim() == "" || textBoxGiri.Text.Trim() == "" || textBoxUglevodi.Text.Trim() == "")
            {
                MessageBox.Show("Необходимо заполнить все поля!");
                return;
            }

            if (!int.TryParse(textBoxBelki.Text.Trim(), out int belki) ||
                !int.TryParse(textBoxGiri.Text.Trim(), out int giri) ||
                !int.TryParse(textBoxUglevodi.Text.Trim(), out int uglevodi) ||
                belki < 0 || giri < 0 || uglevodi < 0)
            {
                MessageBox.Show("Белки, жиры и углеводы должны быть целыми неотрицательными числами");
                return;
            }

            if (!productFromDb.CheckProduct(name))
            {
                return;
            }

            if (productFromDb.ProductAdd(new Product(0, name, belki, giri, uglevodi)))
            {
                DialogResult = true;
            }
        }
    }
}
