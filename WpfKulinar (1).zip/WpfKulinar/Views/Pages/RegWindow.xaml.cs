﻿using System.Windows;
using WpfKulinar.DbService;

namespace WpfKulinar.Views
{
    public partial class RegWindow : Window
    {
        UserFromDb userFromDb = new UserFromDb();
        bool byAdmin = false;

        public RegWindow()
        {
            InitializeComponent();
        }

        public RegWindow(bool byAdmin) : this()
        {
            this.byAdmin = byAdmin;
            if (byAdmin)
            {
                Title = "Добавление пользователя";
                btnReg.Content = "Добавить";
            }
        }

        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxName.Text) || string.IsNullOrWhiteSpace(textBoxFam.Text) ||
                string.IsNullOrWhiteSpace(textBoxLogin.Text) || passwordPwd.Password == "" || passwordPwdP.Password == "")
            {
                MessageBox.Show("Необходимо заполнить все поля!");
                return;
            }

            if (!userFromDb.CheckPassword(passwordPwd.Password, passwordPwdP.Password))
            {
                return;
            }

            if (!userFromDb.CheckUser(textBoxLogin.Text))
            {
                return;
            }

            if (!userFromDb.UserAdd(textBoxLogin.Text, passwordPwd.Password, textBoxName.Text, textBoxFam.Text))
            {
                return;
            }

            if (byAdmin)
            {
                DialogResult = true;
                return;
            }

            AuthWindow authWindow = new AuthWindow();
            authWindow.Show();
            Close();
        }
    }
}
