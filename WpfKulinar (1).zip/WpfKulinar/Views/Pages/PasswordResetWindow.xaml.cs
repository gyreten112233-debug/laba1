﻿using System.Windows;
using WpfKulinar.DbService;
using WpfKulinar.Model;

namespace WpfKulinar.Views
{
    public partial class PasswordResetWindow : Window
    {
        UserFromDb userFromDb = new UserFromDb();
        User selectedUser;

        public PasswordResetWindow(User user)
        {
            InitializeComponent();
            selectedUser = user;
            textBlockFio.Text = user.FullName;
        }

        private void btnChange_Click(object sender, RoutedEventArgs e)
        {
            if (passwordNew.Password == "" || passwordRepeat.Password == "")
            {
                MessageBox.Show("Необходимо заполнить все поля!");
                return;
            }

            if (!userFromDb.CheckPassword(passwordNew.Password, passwordRepeat.Password))
            {
                return;
            }

            MessageBoxResult result = MessageBox.Show("Сейчас будет изменен пароль пользователю " + selectedUser.FullName,
                                                      "Сброс пароля", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
            if (result != MessageBoxResult.OK)
            {
                return;
            }

            if (userFromDb.UserResetPassword(selectedUser, passwordNew.Password))
            {
                if (AuthWindow.currentUser != null && AuthWindow.currentUser.UserId == selectedUser.UserId)
                {
                    AuthWindow.currentUser.Password = selectedUser.Password;
                }
                MessageBox.Show("Пароль изменен");
                Close();
            }
        }
    }
}
