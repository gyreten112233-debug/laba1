﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using WpfKulinar.DbService;
using WpfKulinar.Model;

namespace WpfKulinar.Views.Pages
{
    public partial class ProductPage : Page
    {
        ProductFromDb productFromDb = new ProductFromDb();
        ObservableCollection<Product> listProducts = new ObservableCollection<Product>();

        public ProductPage()
        {
            InitializeComponent();
        }

        private void AllProducts()
        {
            listProducts = productFromDb.LoadProducts();
            dataGridProducts.ItemsSource = listProducts;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            AllProducts();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ProductAddWindow productAddWindow = new ProductAddWindow();
            productAddWindow.Owner = Window.GetWindow(this);
            if (productAddWindow.ShowDialog() == true)
            {
                AllProducts();
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Product product = dataGridProducts.SelectedItem as Product;
            if (product == null)
            {
                MessageBox.Show("Выберите продукт для удаления");
                return;
            }

            MessageBoxResult result = MessageBox.Show("Вы действительно хотите удалить данные на " + product.ProductName + "?",
                                                      "Удаление", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes)
            {
                return;
            }

            if (!productFromDb.IsProductFree(product.Id))
            {
                MessageBox.Show("Продукт входит в состав блюд, удалить его нельзя");
                return;
            }

            if (productFromDb.ProductDelete(product.Id))
            {
                AllProducts();
            }
        }
    }
}
