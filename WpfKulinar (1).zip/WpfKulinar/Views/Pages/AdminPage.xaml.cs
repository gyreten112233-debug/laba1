﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using WpfKulinar.DbService;
using WpfKulinar.Model;

namespace WpfKulinar.Views.Pages
{
    public partial class AdminPage : Page
    {
        UserFromDb userFromDb = new UserFromDb();
        ObservableCollection<User> listUsers = new ObservableCollection<User>();

        public AdminPage()
        {
            InitializeComponent();
        }

        private void AllUsers()
        {
            listUsers = userFromDb.LoadUsers();
            dataGridUsers.ItemsSource = listUsers;
        }

        private void SelectUser(int userId)
        {
            foreach (User item in listUsers)
            {
                if (item.UserId == userId)
                {
                    dataGridUsers.SelectedItem = item;
                    dataGridUsers.ScrollIntoView(item);
                    break;
                }
            }
        }

        private void ClearFields()
        {
            textBoxName.Text = "";
            textBoxPatronymic.Text = "";
            textBoxLastName.Text = "";
            datePickerBirthday.SelectedDate = null;
            textBoxPhone.Text = "";
            textBoxAdress.Text = "";
            comboBoxRole.SelectedIndex = -1;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (AuthWindow.currentUser == null || AuthWindow.currentUser.RoleId != 1)
            {
                return;
            }

            comboBoxRole.ItemsSource = userFromDb.LoadRoles();
            AllUsers();
        }

        private void dataGridUsers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            User user = dataGridUsers.SelectedItem as User;
            if (user == null)
            {
                ClearFields();
                return;
            }

            textBoxName.Text = user.FirstName;
            textBoxPatronymic.Text = user.Patronymic;
            textBoxLastName.Text = user.LastName;
            datePickerBirthday.SelectedDate = user.DateOfBirthday == DateTime.MinValue ? (DateTime?)null : user.DateOfBirthday;
            textBoxPhone.Text = user.Phone;
            textBoxAdress.Text = user.Adress;
            comboBoxRole.SelectedValue = user.RoleId;
        }

        private void btnChangeRole_Click(object sender, RoutedEventArgs e)
        {
            User user = dataGridUsers.SelectedItem as User;
            if (user == null)
            {
                MessageBox.Show("Выберите пользователя");
                return;
            }

            if (comboBoxRole.SelectedValue == null)
            {
                MessageBox.Show("Выберите роль");
                return;
            }

            int roleId = (int)comboBoxRole.SelectedValue;
            if (roleId == user.RoleId)
            {
                MessageBox.Show("У пользователя уже установлена эта роль");
                return;
            }

            int userId = user.UserId;
            if (userFromDb.UserChangeRole(user, roleId))
            {
                AllUsers();
                SelectUser(userId);
                MessageBox.Show("Роль изменена");
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            RegWindow regWindow = new RegWindow(true);
            regWindow.Owner = Window.GetWindow(this);
            if (regWindow.ShowDialog() == true)
            {
                AllUsers();
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            User user = dataGridUsers.SelectedItem as User;
            if (user == null)
            {
                MessageBox.Show("Выберите пользователя для удаления");
                return;
            }

            if (user.UserId == AuthWindow.currentUser.UserId)
            {
                MessageBox.Show("Нельзя удалить самого себя");
                return;
            }

            MessageBoxResult result = MessageBox.Show("Вы действительно хотите удалить пользователя " + user.FullName + "?",
                                                      "Удаление", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes)
            {
                return;
            }

            if (userFromDb.UserDelete(user))
            {
                AllUsers();
            }
        }

        private void btnResetPassword_Click(object sender, RoutedEventArgs e)
        {
            User user = dataGridUsers.SelectedItem as User;
            if (user == null)
            {
                MessageBox.Show("Выберите пользователя");
                return;
            }

            PasswordResetWindow passwordResetWindow = new PasswordResetWindow(user);
            passwordResetWindow.Owner = Window.GetWindow(this);
            passwordResetWindow.ShowDialog();
        }
    }
}
