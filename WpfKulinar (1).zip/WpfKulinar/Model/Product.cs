﻿namespace WpfKulinar.Model
{
    public class Product
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public int Belki { get; set; }
        public int Giri { get; set; }
        public int Uglevodi { get; set; }

        public Product() { }

        public Product(int id, string productName, int belki, int giri, int uglevodi)
        {
            Id = id;
            ProductName = productName;
            Belki = belki;
            Giri = giri;
            Uglevodi = uglevodi;
        }
    }
}
