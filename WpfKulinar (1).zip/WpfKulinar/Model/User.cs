﻿using System;

namespace WpfKulinar.Model
{
    public class User
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Patronymic { get; set; }
        public DateTime DateOfBirthday { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Phone { get; set; }
        public string Adress { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; } = "";

        public string FullName
        {
            get { return (LastName + " " + FirstName + " " + Patronymic).Trim(); }
        }

        public User(int userId, string firstName, string lastName, string patronymic, DateTime dateOfBirthday,
                    string login, string password, string adress, int roleId, string phone)
        {
            UserId = userId;
            FirstName = firstName;
            LastName = lastName;
            Patronymic = patronymic;
            DateOfBirthday = dateOfBirthday;
            Login = login;
            Password = password;
            Adress = adress;
            RoleId = roleId;
            Phone = phone;
        }
    }
}
