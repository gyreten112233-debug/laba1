﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using Npgsql;
using WpfKulinar.Model;

namespace WpfKulinar.DbService
{
    internal class ProductFromDb
    {
        public ObservableCollection<Product> LoadProducts()
        {
            ObservableCollection<Product> products = new ObservableCollection<Product>();
            string query = "select product_id, product_name, belki, giri, uglevodi from products order by product_id";

            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnect.ConnectionString))
                {
                    connection.Open();
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    using (NpgsqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = reader.GetInt32(0);
                            string name = reader.IsDBNull(1) ? "" : reader.GetString(1);
                            int belki = reader.IsDBNull(2) ? 0 : Convert.ToInt32(reader.GetValue(2));
                            int giri = reader.IsDBNull(3) ? 0 : Convert.ToInt32(reader.GetValue(3));
                            int uglevodi = reader.IsDBNull(4) ? 0 : Convert.ToInt32(reader.GetValue(4));

                            products.Add(new Product(id, name, belki, giri, uglevodi));
                        }
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return products;
        }

        public bool CheckProduct(string name)
        {
            string query = "select count(*) from products where lower(product_name) = lower(@name)";

            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnect.ConnectionString))
                {
                    connection.Open();
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("name", name);
                        if (Convert.ToInt32(command.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show("Такой продукт уже есть");
                            return false;
                        }
                        return true;
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public bool ProductAdd(Product product)
        {
            string query = "insert into products (product_name, belki, giri, uglevodi) values (@name, @belki, @giri, @uglevodi)";

            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnect.ConnectionString))
                {
                    connection.Open();
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("name", product.ProductName);
                        command.Parameters.AddWithValue("belki", product.Belki);
                        command.Parameters.AddWithValue("giri", product.Giri);
                        command.Parameters.AddWithValue("uglevodi", product.Uglevodi);
                        command.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public bool IsProductFree(int productId)
        {
            string query = "select count(*) from sostav where product_id = @productId";

            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnect.ConnectionString))
                {
                    connection.Open();
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("productId", productId);
                        return Convert.ToInt32(command.ExecuteScalar()) == 0;
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public bool ProductDelete(int productId)
        {
            string query = "delete from products where product_id = @productId";

            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(DbConnect.ConnectionString))
                {
                    connection.Open();
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("productId", productId);
                        command.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
    }
}
